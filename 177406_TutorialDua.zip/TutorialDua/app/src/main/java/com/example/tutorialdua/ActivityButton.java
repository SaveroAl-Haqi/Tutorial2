package com.example.tutorialdua;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityButton extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.control_button);
    }
}
